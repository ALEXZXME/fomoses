'use client'

import { useState, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import Image from 'next/image'

export default function Home() {
  const [visible, setVisible] = useState(false)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [maskSize, setMaskSize] = useState(Math.max(window.innerWidth, window.innerHeight))
  const [formData, setFormData] = useState({
    email: '',
    role: '',
    contribution: ''
  })
  const [darkness, setDarkness] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      const scrolled = window.scrollY > 100
      setVisible(scrolled)

      const maxScroll = document.documentElement.scrollHeight - window.innerHeight
      const scrollPercentage = window.scrollY / maxScroll
      const newSize = 300 + (Math.max(window.innerWidth, window.innerHeight) - 300) * scrollPercentage
      setMaskSize(newSize)

      const newDarkness = Math.min(scrollPercentage * 0.7, 0.7)
      setDarkness(newDarkness)

      const neonEffect = document.querySelector('.neon-effect') as HTMLElement;
      if (neonEffect) {
        neonEffect.style.width = `${newSize * 2}px`;
        neonEffect.style.height = `${newSize * 2}px`;
      }
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log('Form submitted:', formData)
    setIsModalOpen(false)
  }

  return (
    <div className="min-h-[200vh] relative overflow-hidden">
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-black" />
        <div 
          className="w-full h-full relative overflow-hidden"
          style={{
            maskImage: `radial-gradient(circle ${maskSize}px at 50% 50%, black 100%, transparent 100%)`,
            WebkitMaskImage: `radial-gradient(circle ${maskSize}px at 50% 50%, black 100%, transparent 100%)`,
          }}
        >
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/20241116-170924.jpg-2ChHHgKq8keYwGeCbVDuIsodLSm1lG.jpeg"
            alt="Cyberpunk background"
            layout="fill"
            objectFit="cover"
            quality={100}
          />
          <div 
            className="absolute inset-0 bg-black transition-opacity duration-300 ease-in-out" 
            style={{ opacity: darkness }}
          />
        </div>
        <div 
          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 pointer-events-none neon-effect"
          style={{
            width: `${maskSize * 2}px`,
            height: `${maskSize * 2}px`,
            borderRadius: '50%',
            border: '30px solid transparent', 
            backgroundImage: 'linear-gradient(90deg, #ff00ff, #00ffff, #ff00ff)',
            backgroundClip: 'padding-box',
            WebkitMask: 'linear-gradient(#fff 0 0) padding-box, linear-gradient(#fff 0 0)',
            WebkitMaskComposite: 'xor',
            maskComposite: 'exclude',
            animation: 'neonPulse 5s ease infinite, rotateGradient 10s linear infinite',
          }}
        />
      </div>
      <div className="fixed inset-0 pointer-events-none z-20">
        <div 
          className={`flex flex-col items-center justify-center min-h-screen transition-opacity duration-1000`}
          style={{ opacity: darkness / 0.7 }}
        >
          <div className="glitch-wrapper mb-4">
            <h1 className="glitch text-[5.625rem] font-bold text-white" data-text="YOU ARE PROMISED">
              YOU ARE PROMISED
            </h1>
          </div>
          <p className="text-xl mb-8 text-cyan-400 font-mono tracking-widest animate-pulse">by Project Moses</p>
          <Button 
            onClick={() => setIsModalOpen(true)}
            className="bg-gradient-to-r from-cyan-400 to-purple-600 hover:from-cyan-500 hover:to-purple-700 text-white px-8 py-3 rounded-md text-lg font-bold transition-all hover:scale-105 pointer-events-auto border border-cyan-300 shadow-lg shadow-cyan-500/50 uppercase tracking-wider"
          >
            Join Us
          </Button>
        </div>
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
          <span className="sr-only">Scroll down to reveal more content</span>
          <div className="mouse_scroll">
            <div className="mouse">
              <div className="wheel"></div>
            </div>
            <div>
              <span className="m_scroll_arrows unu"></span>
              <span className="m_scroll_arrows doi"></span>
              <span className="m_scroll_arrows trei"></span>
            </div>
          </div>
        </div>
      </div>

      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="bg-black/90 border-2 border-cyan-500 text-white max-w-md rounded-lg shadow-2xl shadow-cyan-500/50">
          <DialogHeader>
            <DialogTitle className="text-3xl font-bold text-center text-cyan-400 font-mono tracking-wider">Join Project Moses</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-cyan-300 font-mono">Email</Label>
              <Input
                id="email"
                type="email"
                required
                className="bg-black/70 border-cyan-500 text-cyan-100 focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="role" className="text-cyan-300 font-mono">Your Role</Label>
              <Select 
                value={formData.role}
                onValueChange={(value) => setFormData({ ...formData, role: value })}
              >
                <SelectTrigger className="bg-black/70 border-cyan-500 text-cyan-100 focus:ring-2 focus:ring-purple-600 focus:border-transparent">
                  <SelectValue placeholder="Select your role" />
                </SelectTrigger>
                <SelectContent className="bg-black border-cyan-500 text-cyan-100">
                  <SelectItem value="media">Media</SelectItem>
                  <SelectItem value="kol">KOL</SelectItem>
                  <SelectItem value="player">Player</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="contribution" className="text-cyan-300 font-mono">How can you help?</Label>
              <Textarea
                id="contribution"
                required
                className="bg-black/70 border-cyan-500 text-cyan-100 min-h-[100px] focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                value={formData.contribution}
                onChange={(e) => setFormData({ ...formData, contribution: e.target.value })}
              />
            </div>
            <Button 
              type="submit"
              className="w-full bg-gradient-to-r from-cyan-400 to-purple-600 hover:from-cyan-500 hover:to-purple-700 text-white py-2 rounded-md text-lg font-bold transition-all hover:scale-105 uppercase tracking-wider shadow-lg shadow-cyan-500/50"
            >
              Submit
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}